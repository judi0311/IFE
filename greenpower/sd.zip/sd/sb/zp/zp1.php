<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
	<title>Your Website Title</title>
	<meta name="description" content="Website Description" />
	<meta name="keywords" content="Website Kwywords" />
	<style type="text/css" media="all">
	@import "../style/style.css";.STYLE1 {
	font-size: medium;
	font-weight: bold;
}
    .STYLE3 {font-size: xx-large; font-weight: bold; }
    .STYLE4 {font-size: medium}
    .STYLE5 {font-size: x-large}
    </style>
	<!--[if lt IE 7]>
	<style type="text/css">@import "style/ie.css";</style>
	<script src="script/DD_belatedPNG.js" type="text/javascript"></script>
	<script type="text/javascript">
		DD_belatedPNG.fix('#logo span, #loginarea, #panellogin, .textboxlogin, img');
	</script>
	<![endif]-->
	<!--[if IE 7]><style type="text/css">@import "style/ie7.css";</style><![endif]-->
	<script src="../script/jquery.js" type="text/javascript"></script>
	<script src="../script/ui_core.js" type="text/javascript"></script>
	<script src="../script/ui_tabs.js" type="text/javascript"></script>
	<script src="../script/lightbox.js" type="text/javascript"></script>
	<script src="../script/twitter.js" type="text/javascript"></script>
	<script src="../script/gettwitter.js" type="text/javascript"></script>
	<script type="text/javascript">
	$(function() {
		$("#butslide").click(function(){
				$("#panellogin").slideToggle("fast");
				$(this).toggleClass("active"); return false;
		}); 
		$('#tabsnav').tabs({ fx: { opacity: 'toggle' } });
		$('a.popup').lightBox({fixedNavigation:true});
	});
	</script>
</head>
<body>
<?php include("../inc/header.php");?>
		<div id="content">
		
		<ul>
						<li><h1 align="center" class="STYLE3">������Ƹ��</h1>
							<br><br/>
							<h2 align="left" class="STYLE5">������Ƹ��Ϣ</h2>
							
							<p> <span class="STYLE1">1.������Ϣ</span>   Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec placerat, mi eu posuere facilisis, dolor sapien auctor orci, vel posuere velit nibh ac tortor. Donec nunc orci, interdum vel iaculis nec, tincidunt sed diam. Nunc a arcu erat. Integer sed odio tellus, a porta purus.Proin eu metus nulla, a aliquet ante.							</p>
							<p>
							<span class="STYLE1">2.��Ƹ��Ϣ</span>   Vestibulum sed mauris in nisi suscipit ullamcorper sit amet vel dui. Praesent commodo feugiat lectus, eget hendrerit risus viverra a. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec placerat, mi eu posuere facilisis, dolor sapien auctor orci, vel posuere velit nibh ac tortor. Suspendisse velit erat, sodales id iaculis non, dapibus ut lacus. Nulla facilisi. Ut dui sapien, vulputate id tincidunt nec, semper quis arcu. </p>
						<br><br/>
						<h3 align="left" class="STYLE5">�о�����</h3>
						<p>�о�����1hfgdsgfhgjkfdjkhythogqeiurhgyr;dltkjhcgjhb</p>
						<p>�о�����2hdujhdifoghjfkghaerj;wpyjugrfghhfjwrtsfhiqer</p> 
						<p>�о�����3tysgjkfshdkhjigdsurgklsdfhgfbk.ncvjkbhjjgv</p>						
						<br><br/>
						<h3 align="left" class="STYLE5">Ƹ�ô���</h3>
						<p>
						 Vestibulum sed mauris in nisi suscipit ullamcorper sit amet vel dui. Praesent commodo feugiat lectus, eget hendrerit risus viverra a. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec placerat, mi eu posuere facilisis, dolor sapien auctor orci, vel posuere velit nibh ac tortor. Suspendisse velit erat, sodales id iaculis non, dapibus ut lacus. Nulla facilisi. Ut dui sapien, vulputate id tincidunt nec, semper quis arcu
						</p>						
												
						</li>
						
		  </ul>
		
		
		
		
		
		
		  <div class="clear"></div>
</div>
		<?php include("../inc/footer.php")?>
	</div>
</div>

</body>
</html>