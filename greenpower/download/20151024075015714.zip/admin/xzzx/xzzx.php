<?php include("../checkuser.php"); ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">

<title>��̨����</title>
<link href="../style/style.css" rel="stylesheet" type="text/css" />


</head>

<body >
<h2> �������������ļ� </h2>

<form action="xzzx_save.php" method="post" enctype="multipart/form-data" name="form1">
            <table width="760" border="1" cellspacing="0" cellpadding="0">
              <tr >
                <td >����:
                    <input name="bumen" type="text" id="bumen" size="50"></td>
              </tr>
              <tr >
                <td >�ļ�:
                    <input name="nfj1" type="file" id="nfj1" size="50"></td>
              </tr>
             
            
              <tr align="center">
                <td ><input name="Submit" type="submit" class="bt"value="�ύ��Ϣ">
                <input name="Submit2" type="submit" class="bt" value="������д">                </td>
              </tr>
            </table>
</form>

           
       
</body>
</html>
