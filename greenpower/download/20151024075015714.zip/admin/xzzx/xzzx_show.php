<?php include("../checkuser.php"); ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">

<title>ѧ�ƽ�����վ����</title>
<link href="../style/style.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
function MM_jumpMenu(selObj,restore){ //v3.0
  eval("parent.location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>

</head>

<body >

<h2> �鿴/ɾ�����������ļ� </h2>


                <?php
  				     include("../../inc/condata.php");
				     $sql = "select * from yjs_files  order by autoid desc";
				     $result = mysql_query($sql,$db);    
				     if(mysql_num_rows($result) == 0) {
				  ?>
                </a>
                <table width="500" height="100" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td><table width="150" height="20" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#0066FF">
                      <tr>
                        <td align="center"><span >û���κ���Ϣ</span></td>
                          </tr>
                      </table></td>
                    </tr>
                  </table>
                  <a href="../../new1.php">
                  <?php }else{
				        if(isset($_GET['page'])) $page = $_GET['page'];//ע��Ҫ�ӣ���
				        $num = mysql_num_rows($result);
				        $pagesize = 20;
				        $pages = $num % $pagesize == 0 ? $num / $pagesize : floor($num / $pagesize) + 1; 
				        if(isset($page)) {
				          $page = $page < 1 ? 1 : $page;
				          $page = $page > $pages ? $pages : $page;
				          } else {
				              $page = 1;
				     	}
				        $firstline = ($page - 1) * $pagesize;               
				  	    $lastline = $page * $pagesize > $num ? $num - ($page - 1) * $pagesize : $pagesize;
				  	    mysql_free_result($result);
				  	    $sql = "select * from yjs_files order by autoid desc limit ".$firstline.",".$lastline;
				        $result=mysql_query($sql,$db);
				   ?>
                  </a>
                  <form name="form1" method="post" action="xzzx_del.php">
                  <table width="760" border="1" cellspacing="0" cellpadding="5">
                    <tr>
                      <td width="26" >&nbsp;</td>
                        <td width="391"  >�ļ���</td>
                        <td width="189"  >����</td>
                        <td width="421"  >����ʱ��</td>
                      </tr>
                    
                    <?php
					     $j = 1;
                        while($rows = mysql_fetch_array($result)){
                          echo "<tr onMouseOver=\"this.bgColor='#EFEFEF'\" onMouseOut=\"this.bgColor='#FFFFFF'\"><td height=\"20\" align=\"center\">";
						  echo "<input name=\"infdel".$j."\" type=\"checkbox\" value=\"".$rows['autoid']."\">";
					      $rowsnfj = explode("*",$rows['filename']);
						 						  						  
						  echo "</td><td height=\"20\">";
						   if($rows[filetype] == "3") echo "<b class=\"link1\">[�����ϴ�]</b>";
						  
						   echo "<a href=\"../../download/$rowsnfj[0]\" class=\"link1\" target=\"_blank\">$rowsnfj[1]</a></td>";
						    echo "<td height=\"20\" class=\"link1\">$rows[bumen]</td>";
                          echo "<td height=\"20\" class=\"link1\">$rows[filetime]</td></tr>";
						  $j ++;
						}
					   ?>
                    
                    <tr >
                      <td ><span class="font2">   </span></td>
                        <td height="20" colspan="3"  class="font2"><a href="../manage1a.php">
                          <?php
                        echo "�����ļ���: $num �� �� $pages ҳ ��ǰ�� $page ҳ";
                        if ($page > 1)
                            echo " <a href=\"xzzx_show.php?page=".intval($page-1)."\" >��һҳ</a> ";

                        if ($page <> $pages)
                      	    echo " <a href='xzzx_show.php?page=".intval($page+1)."'>��һҳ</a> ";
						  
                      	echo " ת��ҳ";
                        echo "<select onChange='MM_jumpMenu(this,0)' >";
                        echo "<option>��ѡ��</option>";
                        for ($i=1;$i<=$pages;$i++) {
                             echo "<option value='xzzx_show.php?page=$i'>$i</option>";
                             }
                        echo "</select>";
						?>
                        </a></td>
                      </tr>
                    <tr>
                      <td >&nbsp;</td>
                        <td ><input type="submit" name="Submit" value="ȷ��ɾ��">
                          <input type="reset" name="Submit2" value="����ѡ��">
                          <input name="page" type="hidden" id="item" value="<?php echo $_REQUEST['page']; ?>">                      </td>
                        <td>&nbsp;</td>
                        <td >&nbsp;</td>
                      </tr>
                    </table>
                  </form>
                <?php } ?>       
           

</body>
</html>
