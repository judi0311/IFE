<?php include("../checkuser.php"); ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">

<title>��̨����</title>
<link href="../style/style.css" rel="stylesheet" type="text/css" />


</head>

<body >



            <table width="760" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td>
               <?php 
					    if($_FILES['nfj1']['name']== ""){
					 ?>
			  <table width="500" height="100" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td align="center" ><table width="150" height="20" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#0066FF">
                        <tr>
                          <td align="center" >��Ϣ������</td>
                        </tr>
                    </table>
                      <br>       <br>
                      <input name="Submit" type="button" class="bt" value="����" onClick="history.go(-1);"/></td>
                  </tr>
                </table>
				 <?php 
					    }else{
  				           include("../../inc/condata.php");						   
  				           srand((double)microtime()*1000000);
  				           $randval = rand(100,999);

						   if($_FILES['nfj1']['name'] != "") { 
						      $downloadname1a = $_FILES['nfj1']['name']; 
						      srand((double)microtime()*1000000);
						      $randval = rand(100,999);
						      $exname1 = explode(".",$_FILES['nfj1']['name']);
						      end($exname1);
						      $downloadname1b = date("YmdHis").$randval.".".current($exname1); 
						      @move_uploaded_file($_FILES['nfj1']['tmp_name'],"../../download/".$downloadname1b); 
						 	  $downloadname1 = $downloadname1b."*".$downloadname1a; 
						 	 }
						   $ntime  = date("Y-m-d");
						   $bumen=$_POST['bumen'];
  				           $sql = "insert into yjs_files(filename,filetime,filetype,bumen) values ('$downloadname1','$ntime','1','$bumen')";
						   mysql_query($sql,$db);
						   mysql_close($db);
						   ?>
				
              
                <table width="500" height="100" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td align="center" ><table width="150" height="20" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#0066FF">
                        <tr>
                          <td align="center" >��Ϣ���ӳɹ�</td>
                        </tr>
                    </table>
                      <input name="Submit" type="button" class="bt" value="����" onClick="history.go(-1);"/></td>
                  </tr>
                </table>
				<?php
					  }
				   ?>
				</td>
            </tr>
          </table>
       
</body>
</html>
