<?php include("../checkuser.php"); ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>��̨����</title>
<link href="../style/style.css" rel="stylesheet" type="text/css" />


</head>
<body>
<h2>������Ա��Ϣ����</h2>

<?php 
		
						$herror = 0;
					    if(   $_POST['name'] == "" || $_POST['mz'] == ""|| 
						   $_POST['email'] == ""    )
						{
						   $herror = 1;
					 ?>
                  <table width="500" height="100" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" valign="bottom"><table width="150" height="20" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#0066FF">
                            <tr>
                              <td align="center" >��Ϣ������</td>
                            </tr>
                          </table>
                            <br>
                            <br>
                            <span><a href="new1b.php">�������������ӡ�</a></span></td>
                      </tr>
                    </table>
                  <?php }else {
						if($_FILES['image']['name'] != ""){						
						   if($_FILES['image']['type'] != "image/pjpeg"){
						      $herror = 1;
					?>
                  <table width="500" height="100" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" valign="bottom"><table width="150" height="20" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#0066FF">
                            <tr>
                              <td align="center" >ͼƬ��ʽ����</td>
                            </tr>
                          </table>
                            <br>
                            <br>
                            <span><a href="new1b.php">�������������ӡ�</a></span></td>
                      </tr>
                    </table>
                  <?php }else{
						      if($_FILES['image']['size'] > 204800){
						      $herror = 1;
					 ?>
                  <table width="500" height="100" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" valign="bottom"><table width="150" height="20" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#0066FF">
                            <tr>
                              <td align="center" >ͼƬ����200K</td>
                            </tr>
                          </table>
                            <br>
                            <br>
                            <span><a href="new1b.php">�������������ӡ�</a></span></td>
                      </tr>
                    </table>
                  <?php 
                        }
                        }
                        }
					    }
                        if($herror == 0){
  				           include("../../inc/condata.php");						   
  				           srand((double)microtime()*1000000);
  				           $randval = rand(100,999);

  				           if($_FILES['image']['name'] != ""){
  				             $exname1 = explode(".",$_FILES['image']['name']);
  				             end($exname1);
  				             $exname2 = ".".current($exname1);
  				             $puimagesname = date("YmdHis").$randval.$exname2;
  				             $uploadfile = "../../uploads/".$puimagesname;
  				             move_uploaded_file($_FILES['image'][tmp_name],$uploadfile);
  				           }
						  $puimagesname;
					
						 
						$name = $_POST[name];
	              
						$xb= $_POST[xb];
						$mz = $_POST[mz];
						$zw = $_POST[zw];
						$bgdd = $_POST[bgdd];
						$tel = $_POST[tel];
						$email = $_POST[email];
						$zzfw = $_POST[zzfw];
						
				    $sqlstr = "insert into `yjs_gzry` (`name`,`image`,`xb`,`mz`,`zw`,`bgdd`,`tel`,`email`,`zzfw`) VALUES                                           ('$name','$puimagesname','$xb','$mz','$zw','$bgdd','$tel','$email','$zzfw')";
					
				$result = mysql_query($sqlstr,$db);
				if ($result){
		
			}
			else
				echo "<script>alert('����ʧ��');history.go(-1);</script>";
						  

						   mysql_query($sql,$db);
						   mysql_close($db); 
						  
						  
						   ?>
                    <table width="500" height="100" border="1" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" valign="bottom"><table width="150" height="20" border="0" align="center" cellpadding="0" cellspacing="0" >
                            <tr>
                              <td align="center" >��Ϣ���ӳɹ�,���<a href='../szdw/szdw.php' >����</a>�鿴</td>
                            </tr>
                          </table>
                            <br>
                            <br>
                            <span><a href="ds.php">�����ء�</a></span></td>
                      </tr>
                    </table>
                  <?php
					  }
				   ?>
           

             
</body>
</html>
