<?php include("../checkuser.php"); ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>��̨����</title>
<link href="../style/style.css" rel="stylesheet" type="text/css" />


</head>
<body>
<h2>������Ա��Ϣ�޸�</h2>
<?php
  				     include_once("../../inc/condata.php");
					 	  srand((double)microtime()*1000000);
  				           $randval = rand(100,999);

  				           if($_FILES['image']['name'] != ""){
  				             $exname1 = explode(".",$_FILES['image']['name']);
  				             end($exname1);
  				             $exname2 = ".".current($exname1);
  				             $puimagesname = date("YmdHis").$randval.$exname2;
  				             $uploadfile = "../../uploads/".$puimagesname;
  				             move_uploaded_file($_FILES['image'][tmp_name],$uploadfile);
  				           }
						  $puimagesname;
						 $id=$_GET[id];
					
				$sql = "select * from yjs_gzry where autoid= '$id '";					 
				
			
						$name = $_POST[name];
	                    $image= $puimagesname;
						$xb= $_POST[xb];
						$mz = $_POST[mz];
						$zw = $_POST[zw];
						$bgdd = $_POST[bgdd];
						$tel = $_POST[tel];
						$email = $_POST[email];
						$zzfw = $_POST[zzfw];
				    $sqlstr ="update `yjs_gzry` set name='$name',image='$image' ,xb='$xb',mz='$mz', zw='$zw',bgdd='$bgdd', tel='$tel',          email='$email' , zzfw='$zzfw' where autoid=$id";
					
				   $result = mysql_query($sqlstr,$db);
				   if ($result){
		          	echo "<p>���ӳɹ�!</p>";
			      }
			else
				echo "<script>alert('�޸�ʧ��');history.go(-1);</script>";
?>




             
</body>
</html>
